const actions = {
	setUser: 'SET_USER',
	showMessage: 'SHOW_MESSAGE',
	hideMessage: 'HIDE_MESSAGE',
}

export default {
	actions
}
